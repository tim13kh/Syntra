using System;
using System.Collections.Generic;
using System.Text;

namespace Verwissel
{
	class Program
	{
		static void Main( string[] args )
		{
			string var1 = string.Empty,
				   var2 = string.Empty,
				   var3;

			Console.Write( "Geef de eerste tekst in: " );
			var1 = Console.ReadLine( );

			Console.Write( "Geef de tweede tekst in: " );
			var2 = Console.ReadLine( );

			var3 = var1;
			var1 = var2;
			var2 = var3;

			Console.WriteLine( "{0}, {1}", var1, var2 );
		}
	}
}
