using System;
using System.Collections.Generic;
using System.Text;

namespace Temperatuur
{
	class Program
	{
		static void Main( string[] args )
		{
			float tempCel,
				tempFar;

			Console.Write( "Geef het aantal graden Celcius in: " );
			tempCel = float.Parse( Console.ReadLine( ) );

			tempFar = ( tempCel * 9 / 5 ) + 32;
			Console.WriteLine( "{0} graden Celcius = {1:0.00} Farenheit", tempCel, tempFar );
		}
	}
}
