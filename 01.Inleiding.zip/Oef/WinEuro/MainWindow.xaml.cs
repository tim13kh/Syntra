﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinEuro
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btToBEF_Click(object sender, RoutedEventArgs e)
        {
            float bedragEuro = float.Parse(txtBedrag.Text);
            float bedragBef = bedragEuro * 1.07f;

            MessageBox.Show(string.Format("{0} Euro is {1} Dollar.", bedragEuro, bedragBef));
        }

        private void btToEuro_Click(object sender, RoutedEventArgs e)
        {
            float bedragBef = float.Parse(txtBedrag.Text);
            float bedragEuro = bedragBef / 1.07f;

            MessageBox.Show(string.Format("{0} Dollar. is {1} Euro.", bedragBef, bedragEuro));
        }
    }
}
