using System;
using System.Collections.Generic;
using System.Text;

namespace Verkoop
{
	class Program
	{
		static void Main( string[] args )
		{
			float prijsExcl,
				prijs;
			int btwPrcnt;

			Console.Write( "Geef de prijs in (excl. BTW): " );
			prijsExcl = float.Parse( Console.ReadLine( ) );

			Console.Write( "Geef het BTW percentage in: " );
			btwPrcnt = int.Parse( Console.ReadLine( ) );

			prijs = prijsExcl * ( 1 + (float)btwPrcnt/100);
			Console.WriteLine( "De prijs met BTW: {0}", prijs );
		}
	}
}
