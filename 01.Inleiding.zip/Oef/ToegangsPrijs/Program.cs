using System;
using System.Collections.Generic;
using System.Text;

namespace ToegangsPrijs
{
	class Program
	{
		static void Main( string[] args )
		{
			int aantalAdult, aantalKids,
				toegangsPrijs;

			Console.Write( "Geef het aantal volwassenen: " );
			aantalAdult = int.Parse( Console.ReadLine( ) );

			Console.Write( "Geef het aantal kinderen: " );
			aantalKids = int.Parse( Console.ReadLine( ) );

			toegangsPrijs = ( aantalAdult * 15 ) + ( aantalKids * 10 );
			Console.WriteLine( "de totale toegangsprijs is: {0}", toegangsPrijs );
		}
	}
}
