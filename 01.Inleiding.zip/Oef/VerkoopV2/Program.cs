using System;
using System.Collections.Generic;
using System.Text;

namespace VerkoopV2
{
	class Program
	{
		static void Main( string[] args )
		{
			string naam;
			float prijsInkoop,
				prijs;
			int winst;

			Console.Write( "Geef de artikelnaam in: " );
			naam = Console.ReadLine( );

			Console.Write( "Geef de inkoopprijs in: " );
            prijsInkoop = float.Parse(Console.ReadLine());

			Console.Write( "Geef het winstpercentage in: " );
			winst = int.Parse( Console.ReadLine( ) );

            prijs = prijsInkoop * (1 + (float)winst / 100);
			Console.WriteLine( "De verkoopprijs van '{0}': {1}", naam, prijs );

		}
	}
}
