﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    class Program
    {

        /// <summary>
        /// Mijn hoofdfunctie
        /// </summary>
        /// <param name="args">start-up argumenten</param>
        static void Main(string[] args)
        {
            #region Declaratie
            //1 regel info

            string naam = "";
            string adres = string.Empty;
            var city = string.Empty;
            var country = "";
            var leeftijd = 1;

            /*
             fsas
             * sSKfsk\f
             * S\dggasg\
             * 
             */
            #endregion

            Console.Write("Geef je naam in: ");
            naam = Console.ReadLine();

            Console.WriteLine("Hello " + naam);

            Console.ReadKey();
        }
    }
}
