﻿using System;
using HelloWorld.Business;

namespace HelloWorld.Tmp
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = string.Empty;
            var leeftijd = 0;

            Product p = new Product();
            var p2 = new Product();

            name = Console.ReadLine();
            Console.WriteLine("Hello world!");
            Console.WriteLine("Hello " + name + "!");
            Console.WriteLine("Hello {0}!", name);
        }
    }
}
